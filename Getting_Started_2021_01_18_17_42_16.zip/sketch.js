function setup() {
  createCanvas(400, 300);
}

function draw() {
  background(20, 100, 200, 50);
  fill(200)
  rectMode(CENTER);
  stroke(1000);
  fill(100, 0, 200);
  rect(200, 150, 300, 200, 100);
  stroke(0, 200, 300);
  strokeWeight(15);
  line(0, 0, 400, 300);
  line(300, 400, 0, 0);
  line(0, 0, 250, 300);
  line(0, 0, 200, 300);
  line(0, 0, 275, 300);
  line(0, 0, 280, 300);
  stroke(0, 200, 30);
  strokeWeight(3);
  line(0, 0, 400, 300);
  line(300, 400, 0, 0);
  line(0, 0, 250, 300);
  line(0, 0, 200, 300);
  line(0, 0, 275, 300);
  line(0, 0, 280, 300);
  //this is the yellow circle - later I want to   
  //make this circle animate
  fill(200, 255, 0);
  strokeWeight(10);
  translate(p5.Vector.fromAngle(millis() / 1000, 40));
  //rotate(100,100);not sure how this rotate  
  //function works
  strokeWeight(5);
  ellipse(200, 100, 50, 50);
  fill(100, 0, 100, 50);


}